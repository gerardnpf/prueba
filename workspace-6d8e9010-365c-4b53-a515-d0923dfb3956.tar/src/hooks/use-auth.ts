'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'

interface User {
  id: string
  name: string
  email: string
}

export function useAuth() {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    // Only run on client side
    if (typeof window === 'undefined') return

    const checkAuth = () => {
      try {
        const userData = localStorage.getItem('user')
        if (userData) {
          const parsedUser = JSON.parse(userData)
          if (parsedUser && parsedUser.id && parsedUser.email) {
            setUser(parsedUser)
          } else {
            // Invalid data, clear it
            localStorage.removeItem('user')
            setUser(null)
          }
        } else {
          setUser(null)
        }
      } catch (error) {
        console.error('Error checking auth:', error)
        // Clear corrupted data
        localStorage.removeItem('user')
        setUser(null)
      } finally {
        setIsLoading(false)
      }
    }

    // Small delay to ensure proper mounting
    const timer = setTimeout(checkAuth, 100)

    return () => clearTimeout(timer)
  }, [])

  const login = (userData: User) => {
    try {
      localStorage.setItem('user', JSON.stringify(userData))
      setUser(userData)
    } catch (error) {
      console.error('Error saving user data:', error)
    }
  }

  const logout = () => {
    try {
      localStorage.removeItem('user')
      setUser(null)
      router.push('/')
    } catch (error) {
      console.error('Error during logout:', error)
    }
  }

  const requireAuth = () => {
    if (isLoading) return false
    
    if (!user) {
      // Only redirect if not already on auth pages
      if (typeof window !== 'undefined') {
        const currentPath = window.location.pathname
        if (!['/login', '/register', '/'].includes(currentPath)) {
          router.push('/login')
        }
      }
      return false
    }
    return true
  }

  return {
    user,
    isLoading,
    isAuthenticated: !!user,
    login,
    logout,
    requireAuth
  }
}