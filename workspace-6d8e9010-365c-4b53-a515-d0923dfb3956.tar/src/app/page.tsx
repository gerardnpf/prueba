'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { DollarSign, TrendingUp, Target, PiggyBank } from 'lucide-react'

export default function Home() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  // Don't render anything until mounted (prevents hydration issues)
  if (!mounted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Cargando...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 to-secondary/10">
      <div className="container mx-auto px-4 py-16">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Zen Finance
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Tu compañero inteligente para gestionar presupuestos mensuales, 
            alcanzar metas financieras y tomar control de tu futuro económico.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild>
              <Link href="/register">
                Comenzar Gratis
                <DollarSign className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/login">
                Iniciar Sesión
              </Link>
            </Button>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          <Card className="text-center">
            <CardHeader>
              <div className="mx-auto mb-4 p-3 bg-primary/10 rounded-full w-fit">
                <DollarSign className="h-8 w-8 text-primary" />
              </div>
              <CardTitle>Control de Gastos</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Registra y categoriza todos tus ingresos y gastos en un solo lugar
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="mx-auto mb-4 p-3 bg-primary/10 rounded-full w-fit">
                <TrendingUp className="h-8 w-8 text-primary" />
              </div>
              <CardTitle>Presupuestos Inteligentes</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Establece límites mensuales y recibe alertas cuando te acerques a ellos
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="mx-auto mb-4 p-3 bg-primary/10 rounded-full w-fit">
                <Target className="h-8 w-8 text-primary" />
              </div>
              <CardTitle>Metas de Ahorro</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Define objetivos financieros y sigue tu progreso hacia ellos
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="mx-auto mb-4 p-3 bg-primary/10 rounded-full w-fit">
                <PiggyBank className="h-8 w-8 text-primary" />
              </div>
              <CardTitle>Modo Pareja</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Comparte finanzas con tu pareja de forma transparente y organizada
              </CardDescription>
            </CardContent>
          </Card>
        </div>

        {/* CTA Section */}
        <Card className="text-center p-8">
          <CardHeader>
            <CardTitle className="text-3xl">¿Listo para tomar control de tus finanzas?</CardTitle>
            <CardDescription className="text-lg">
              Únete a miles de personas que ya gestionan su presupuesto con Zen Finance
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button size="lg" asChild>
              <Link href="/register">
                Crear Cuenta Gratuita
                <DollarSign className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}