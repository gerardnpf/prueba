'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  Plus, 
  Target,
  AlertTriangle,
  CheckCircle,
  TrendingUp,
  Calendar
} from 'lucide-react'

interface User {
  id: string
  name: string
  email: string
}

interface Budget {
  id: string
  amount: number
  spent: number
  category: {
    id: string
    name: string
    icon: string
  }
  month: number
  year: number
}

interface Category {
  id: string
  name: string
  icon: string
  type: string
}

export default function BudgetsPage() {
  const [user, setUser] = useState<User | null>(null)
  const [budgets, setBudgets] = useState<Budget[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [newBudget, setNewBudget] = useState({
    amount: '',
    categoryId: '',
    month: new Date().getMonth() + 1,
    year: new Date().getFullYear()
  })
  const router = useRouter()

  const monthNames = [
    'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
    'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
  ]

  useEffect(() => {
    const userData = localStorage.getItem('user')
    if (!userData) {
      router.push('/login')
      return
    }

    try {
      const parsedUser = JSON.parse(userData)
      if (parsedUser && parsedUser.id) {
        setUser(parsedUser)
        fetchData(parsedUser.id)
      } else {
        localStorage.removeItem('user')
        router.push('/login')
      }
    } catch (error) {
      console.error('Error parsing user data:', error)
      localStorage.removeItem('user')
      router.push('/login')
    }
  }, [router])

  const fetchData = async (userId: string) => {
    try {
      // Fetch budgets
      const budgetsResponse = await fetch(`/api/budgets?userId=${userId}`)
      if (budgetsResponse.ok) {
        const data = await budgetsResponse.json()
        setBudgets(data.budgets || [])
      }

      // Fetch categories
      const categoriesResponse = await fetch(`/api/categories?userId=${userId}`)
      if (categoriesResponse.ok) {
        const data = await categoriesResponse.json()
        setCategories(data.categories || [])
      }
    } catch (error) {
      console.error('Error fetching data:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleAddBudget = async () => {
    if (!user) return

    try {
      const response = await fetch('/api/budgets', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...newBudget,
          userId: user.id
        }),
      })

      if (response.ok) {
        setShowAddDialog(false)
        setNewBudget({
          amount: '',
          categoryId: '',
          month: new Date().getMonth() + 1,
          year: new Date().getFullYear()
        })
        fetchData(user.id)
      }
    } catch (error) {
      console.error('Error adding budget:', error)
    }
  }

  const handleLogout = () => {
    router.push('/logout')
  }

  const getBudgetStatus = (budget: Budget) => {
    const percentage = (budget.spent / budget.amount) * 100
    if (percentage >= 100) return { status: 'exceeded', color: 'text-red-600', bgColor: 'bg-red-100', icon: AlertTriangle }
    if (percentage >= 80) return { status: 'warning', color: 'text-yellow-600', bgColor: 'bg-yellow-100', icon: AlertTriangle }
    return { status: 'good', color: 'text-green-600', bgColor: 'bg-green-100', icon: CheckCircle }
  }

  const totalBudgeted = budgets.reduce((sum, budget) => sum + budget.amount, 0)
  const totalSpent = budgets.reduce((sum, budget) => sum + budget.spent, 0)
  const totalRemaining = totalBudgeted - totalSpent

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
          <p className="mt-4 text-muted-foreground">Cargando...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return null
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold">Zen Finance</h1>
            <p className="text-muted-foreground">Gestión de Presupuestos</p>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={handleLogout}>
              Cerrar Sesión
            </Button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="border-b bg-card">
        <div className="container mx-auto px-4">
          <div className="flex space-x-6">
            <Link href="/dashboard" className="py-3 px-1 border-b-2 border-transparent text-muted-foreground hover:text-foreground">
              Dashboard
            </Link>
            <Link href="/transactions" className="py-3 px-1 border-b-2 border-transparent text-muted-foreground hover:text-foreground">
              Transacciones
            </Link>
            <Link href="/accounts" className="py-3 px-1 border-b-2 border-transparent text-muted-foreground hover:text-foreground">
              Cuentas
            </Link>
            <Link href="/categories" className="py-3 px-1 border-b-2 border-transparent text-muted-foreground hover:text-foreground">
              Categorías
            </Link>
            <Link href="/budgets" className="py-3 px-1 border-b-2 border-primary text-primary font-medium">
              Presupuestos
            </Link>
            <Link href="/savings-goals" className="py-3 px-1 border-b-2 border-transparent text-muted-foreground hover:text-foreground">
              Metas de Ahorro
            </Link>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Presupuestado</CardTitle>
              <Target className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">
                ${totalBudgeted.toFixed(2)}
              </div>
              <p className="text-xs text-muted-foreground">
                Para este mes
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Gastado</CardTitle>
              <TrendingUp className="h-4 w-4 text-orange-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">
                ${totalSpent.toFixed(2)}
              </div>
              <p className="text-xs text-muted-foreground">
                {totalBudgeted > 0 ? `${((totalSpent / totalBudgeted) * 100).toFixed(0)}% del presupuesto` : 'Sin presupuesto'}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Restante</CardTitle>
              <Calendar className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${totalRemaining >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                ${totalRemaining.toFixed(2)}
              </div>
              <p className="text-xs text-muted-foreground">
                {totalRemaining >= 0 ? 'Dentro del presupuesto' : 'Excedido'}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Actions Bar */}
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-semibold">Presupuestos del Mes</h2>
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Nuevo Presupuesto
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Crear Nuevo Presupuesto</DialogTitle>
                <DialogDescription>
                  Establece un límite de gasto para una categoría este mes
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="category">Categoría</Label>
                  <Select value={newBudget.categoryId} onValueChange={(value) => setNewBudget({...newBudget, categoryId: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona una categoría" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories
                        .filter(cat => cat.type === 'expense')
                        .map((category) => (
                          <SelectItem key={category.id} value={category.id}>
                            {category.icon} {category.name}
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="amount">Monto del Presupuesto</Label>
                  <Input
                    id="amount"
                    type="number"
                    step="0.01"
                    value={newBudget.amount}
                    onChange={(e) => setNewBudget({...newBudget, amount: e.target.value})}
                    placeholder="0.00"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="month">Mes</Label>
                    <Select value={newBudget.month.toString()} onValueChange={(value) => setNewBudget({...newBudget, month: parseInt(value)})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {monthNames.map((month, index) => (
                          <SelectItem key={index} value={(index + 1).toString()}>
                            {month}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="year">Año</Label>
                    <Input
                      id="year"
                      type="number"
                      value={newBudget.year}
                      onChange={(e) => setNewBudget({...newBudget, year: parseInt(e.target.value)})}
                    />
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowAddDialog(false)}>
                    Cancelar
                  </Button>
                  <Button onClick={handleAddBudget}>
                    Crear Presupuesto
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Budgets List */}
        {budgets.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <Target className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No hay presupuestos configurados</h3>
              <p className="text-muted-foreground mb-4">
                Crea tu primer presupuesto para empezar a controlar tus gastos
              </p>
              <Button onClick={() => setShowAddDialog(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Crear Primer Presupuesto
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {budgets.map((budget) => {
              const percentage = budget.amount > 0 ? (budget.spent / budget.amount) * 100 : 0
              const status = getBudgetStatus(budget)
              const StatusIcon = status.icon

              return (
                <Card key={budget.id}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="text-2xl">{budget.category.icon}</div>
                        <div>
                          <h3 className="font-semibold text-lg">{budget.category.name}</h3>
                          <p className="text-sm text-muted-foreground">
                            {monthNames[budget.month - 1]} {budget.year}
                          </p>
                        </div>
                      </div>
                      <div className={`flex items-center gap-2 px-3 py-1 rounded-full ${status.bgColor}`}>
                        <StatusIcon className={`h-4 w-4 ${status.color}`} />
                        <span className={`text-sm font-medium ${status.color}`}>
                          {status.status === 'exceeded' ? 'Excedido' : 
                           status.status === 'warning' ? 'Cerca del límite' : 'Dentro del presupuesto'}
                        </span>
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <div className="flex justify-between text-sm">
                        <span>Gastado: ${budget.spent.toFixed(2)}</span>
                        <span>Presupuesto: ${budget.amount.toFixed(2)}</span>
                      </div>
                      <Progress 
                        value={Math.min(percentage, 100)} 
                        className={`h-3 ${percentage >= 100 ? 'bg-red-200' : percentage >= 80 ? 'bg-yellow-200' : ''}`}
                      />
                      <div className="flex justify-between items-center">
                        <span className={`text-sm font-medium ${status.color}`}>
                          {percentage.toFixed(0)}% utilizado
                        </span>
                        <span className={`text-sm font-medium ${status.color}`}>
                          ${Math.max(budget.amount - budget.spent, 0).toFixed(2)} restantes
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        )}
      </main>
    </div>
  )
}