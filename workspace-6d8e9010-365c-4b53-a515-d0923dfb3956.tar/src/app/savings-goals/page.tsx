'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'
import { 
  Plus, 
  Target,
  DollarSign,
  Calendar,
  Trophy,
  TrendingUp
} from 'lucide-react'

interface User {
  id: string
  name: string
  email: string
}

interface SavingsGoal {
  id: string
  name: string
  targetAmount: number
  currentAmount: number
  targetDate?: string
  createdAt: string
}

export default function SavingsGoalsPage() {
  const [user, setUser] = useState<User | null>(null)
  const [savingsGoals, setSavingsGoals] = useState<SavingsGoal[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [showContributeDialog, setShowContributeDialog] = useState(false)
  const [selectedGoal, setSelectedGoal] = useState<SavingsGoal | null>(null)
  const [newGoal, setNewGoal] = useState({
    name: '',
    targetAmount: '',
    targetDate: ''
  })
  const [contributionAmount, setContributionAmount] = useState('')
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem('user')
    if (!userData) {
      router.push('/login')
      return
    }

    try {
      const parsedUser = JSON.parse(userData)
      if (parsedUser && parsedUser.id) {
        setUser(parsedUser)
        fetchSavingsGoals(parsedUser.id)
      } else {
        localStorage.removeItem('user')
        router.push('/login')
      }
    } catch (error) {
      console.error('Error parsing user data:', error)
      localStorage.removeItem('user')
      router.push('/login')
    }
  }, [router])

  const fetchSavingsGoals = async (userId: string) => {
    try {
      const response = await fetch(`/api/savings-goals?userId=${userId}`)
      if (response.ok) {
        const data = await response.json()
        setSavingsGoals(data.goals || [])
      }
    } catch (error) {
      console.error('Error fetching savings goals:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleAddGoal = async () => {
    if (!user) return

    try {
      const response = await fetch('/api/savings-goals', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...newGoal,
          userId: user.id
        }),
      })

      if (response.ok) {
        setShowAddDialog(false)
        setNewGoal({ name: '', targetAmount: '', targetDate: '' })
        fetchSavingsGoals(user.id)
      }
    } catch (error) {
      console.error('Error adding savings goal:', error)
    }
  }

  const handleContribute = async () => {
    if (!user || !selectedGoal) return

    try {
      const response = await fetch('/api/savings-goals/contribute', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          goalId: selectedGoal.id,
          amount: parseFloat(contributionAmount),
          userId: user.id
        }),
      })

      if (response.ok) {
        setShowContributeDialog(false)
        setContributionAmount('')
        setSelectedGoal(null)
        fetchSavingsGoals(user.id)
      }
    } catch (error) {
      console.error('Error contributing to goal:', error)
    }
  }

  const handleLogout = () => {
    router.push('/logout')
  }

  const totalSaved = savingsGoals.reduce((sum, goal) => sum + goal.currentAmount, 0)
  const totalTarget = savingsGoals.reduce((sum, goal) => sum + goal.targetAmount, 0)
  const overallProgress = totalTarget > 0 ? (totalSaved / totalTarget) * 100 : 0

  const getDaysRemaining = (targetDate?: string) => {
    if (!targetDate) return null
    const target = new Date(targetDate)
    const today = new Date()
    const diffTime = target.getTime() - today.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
          <p className="mt-4 text-muted-foreground">Cargando...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return null
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold">Zen Finance</h1>
            <p className="text-muted-foreground">Metas de Ahorro</p>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={handleLogout}>
              Cerrar Sesión
            </Button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="border-b bg-card">
        <div className="container mx-auto px-4">
          <div className="flex space-x-6">
            <Link href="/dashboard" className="py-3 px-1 border-b-2 border-transparent text-muted-foreground hover:text-foreground">
              Dashboard
            </Link>
            <Link href="/transactions" className="py-3 px-1 border-b-2 border-transparent text-muted-foreground hover:text-foreground">
              Transacciones
            </Link>
            <Link href="/accounts" className="py-3 px-1 border-b-2 border-transparent text-muted-foreground hover:text-foreground">
              Cuentas
            </Link>
            <Link href="/categories" className="py-3 px-1 border-b-2 border-transparent text-muted-foreground hover:text-foreground">
              Categorías
            </Link>
            <Link href="/budgets" className="py-3 px-1 border-b-2 border-transparent text-muted-foreground hover:text-foreground">
              Presupuestos
            </Link>
            <Link href="/savings-goals" className="py-3 px-1 border-b-2 border-primary text-primary font-medium">
              Metas de Ahorro
            </Link>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Ahorrado</CardTitle>
              <DollarSign className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                ${totalSaved.toFixed(2)}
              </div>
              <p className="text-xs text-muted-foreground">
                En todas tus metas
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Objetivo Total</CardTitle>
              <Target className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">
                ${totalTarget.toFixed(2)}
              </div>
              <p className="text-xs text-muted-foreground">
                Suma de todas las metas
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Progreso General</CardTitle>
              <Trophy className="h-4 w-4 text-yellow-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-yellow-600">
                {overallProgress.toFixed(0)}%
              </div>
              <Progress value={overallProgress} className="mt-2" />
            </CardContent>
          </Card>
        </div>

        {/* Actions Bar */}
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-semibold">Tus Metas de Ahorro</h2>
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Nueva Meta
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Crear Nueva Meta de Ahorro</DialogTitle>
                <DialogDescription>
                  Define un objetivo financiero y empieza a ahorrar para alcanzarlo
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Nombre de la Meta</Label>
                  <Input
                    id="name"
                    value={newGoal.name}
                    onChange={(e) => setNewGoal({...newGoal, name: e.target.value})}
                    placeholder="Ej: Fondo de emergencia, Vacaciones, Auto nuevo"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="targetAmount">Monto Objetivo</Label>
                  <Input
                    id="targetAmount"
                    type="number"
                    step="0.01"
                    value={newGoal.targetAmount}
                    onChange={(e) => setNewGoal({...newGoal, targetAmount: e.target.value})}
                    placeholder="0.00"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="targetDate">Fecha Objetivo (Opcional)</Label>
                  <Input
                    id="targetDate"
                    type="date"
                    value={newGoal.targetDate}
                    onChange={(e) => setNewGoal({...newGoal, targetDate: e.target.value})}
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowAddDialog(false)}>
                    Cancelar
                  </Button>
                  <Button onClick={handleAddGoal}>
                    Crear Meta
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Goals Grid */}
        {savingsGoals.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <Target className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No hay metas de ahorro configuradas</h3>
              <p className="text-muted-foreground mb-4">
                Crea tu primera meta para empezar a ahorrar hacia tus objetivos
              </p>
              <Button onClick={() => setShowAddDialog(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Crear Primera Meta
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {savingsGoals.map((goal) => {
              const progress = goal.targetAmount > 0 ? (goal.currentAmount / goal.targetAmount) * 100 : 0
              const daysRemaining = getDaysRemaining(goal.targetDate)
              const isCompleted = progress >= 100

              return (
                <Card key={goal.id} className={`${isCompleted ? 'border-green-200 bg-green-50/50' : ''}`}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg flex items-center gap-2">
                        {isCompleted && <Trophy className="h-5 w-5 text-yellow-600" />}
                        {goal.name}
                      </CardTitle>
                    </div>
                    {goal.targetDate && (
                      <CardDescription className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        {daysRemaining !== null && (
                          <span className={daysRemaining < 0 ? 'text-red-600' : daysRemaining < 30 ? 'text-yellow-600' : ''}>
                            {daysRemaining < 0 
                              ? `${Math.abs(daysRemaining)} días vencida`
                              : `${daysRemaining} días restantes`
                            }
                          </span>
                        )}
                      </CardDescription>
                    )}
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Progreso</span>
                          <span className="font-medium">{progress.toFixed(0)}%</span>
                        </div>
                        <Progress value={Math.min(progress, 100)} className="h-2" />
                        <div className="flex justify-between text-sm">
                          <span>${goal.currentAmount.toFixed(2)}</span>
                          <span>${goal.targetAmount.toFixed(2)}</span>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <p className="text-sm text-muted-foreground">
                          Restante: ${Math.max(goal.targetAmount - goal.currentAmount, 0).toFixed(2)}
                        </p>
                      </div>

                      {!isCompleted && (
                        <Button 
                          className="w-full" 
                          onClick={() => {
                            setSelectedGoal(goal)
                            setShowContributeDialog(true)
                          }}
                        >
                          <DollarSign className="h-4 w-4 mr-2" />
                          Contribuir
                        </Button>
                      )}

                      {isCompleted && (
                        <div className="text-center py-2 px-4 bg-green-100 text-green-800 rounded-lg">
                          <p className="font-medium">¡Meta Completada!</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        )}
      </main>

      {/* Contribute Dialog */}
      <Dialog open={showContributeDialog} onOpenChange={setShowContributeDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Contribuir a la Meta</DialogTitle>
            <DialogDescription>
              Agrega dinero a tu meta de ahorro: {selectedGoal?.name}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="contributionAmount">Monto a Contribuir</Label>
              <Input
                id="contributionAmount"
                type="number"
                step="0.01"
                value={contributionAmount}
                onChange={(e) => setContributionAmount(e.target.value)}
                placeholder="0.00"
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowContributeDialog(false)}>
                Cancelar
              </Button>
              <Button onClick={handleContribute}>
                Contribuir
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}