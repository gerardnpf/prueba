import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    
    if (!userId) {
      return NextResponse.json(
        { error: 'userId es requerido' },
        { status: 400 }
      )
    }

    const accounts = await db.account.findMany({
      where: {
        userId
      },
      orderBy: {
        name: 'asc'
      }
    })

    return NextResponse.json({
      accounts
    })

  } catch (error) {
    console.error('Error fetching accounts:', error)
    return NextResponse.json(
      { error: 'Error al obtener cuentas' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const { name, type, balance, userId } = await request.json()

    if (!name || !type || !userId) {
      return NextResponse.json(
        { error: 'Nombre, tipo y userId son obligatorios' },
        { status: 400 }
      )
    }

    const account = await db.account.create({
      data: {
        name,
        type,
        balance: parseFloat(balance) || 0,
        userId
      }
    })

    return NextResponse.json({
      message: 'Cuenta creada exitosamente',
      account
    })

  } catch (error) {
    console.error('Error creating account:', error)
    return NextResponse.json(
      { error: 'Error al crear cuenta' },
      { status: 500 }
    )
  }
}