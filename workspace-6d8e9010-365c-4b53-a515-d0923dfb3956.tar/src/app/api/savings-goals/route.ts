import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    
    if (!userId) {
      return NextResponse.json(
        { error: 'userId es requerido' },
        { status: 400 }
      )
    }

    const goals = await db.savingsGoal.findMany({
      where: {
        userId
      },
      orderBy: {
        createdAt: 'desc'
      }
    })

    return NextResponse.json({
      goals
    })

  } catch (error) {
    console.error('Error fetching savings goals:', error)
    return NextResponse.json(
      { error: 'Error al obtener metas de ahorro' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const { name, targetAmount, targetDate, userId } = await request.json()

    if (!name || !targetAmount || !userId) {
      return NextResponse.json(
        { error: 'Nombre, monto objetivo y userId son obligatorios' },
        { status: 400 }
      )
    }

    const goal = await db.savingsGoal.create({
      data: {
        name,
        targetAmount: parseFloat(targetAmount),
        targetDate: targetDate ? new Date(targetDate) : null,
        userId
      }
    })

    return NextResponse.json({
      message: 'Meta de ahorro creada exitosamente',
      goal
    })

  } catch (error) {
    console.error('Error creating savings goal:', error)
    return NextResponse.json(
      { error: 'Error al crear meta de ahorro' },
      { status: 500 }
    )
  }
}