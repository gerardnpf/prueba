import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const { goalId, amount, userId } = await request.json()

    if (!goalId || !amount || !userId) {
      return NextResponse.json(
        { error: 'goalId, amount y userId son obligatorios' },
        { status: 400 }
      )
    }

    // Get the current goal
    const goal = await db.savingsGoal.findFirst({
      where: {
        id: goalId,
        userId
      }
    })

    if (!goal) {
      return NextResponse.json(
        { error: 'Meta de ahorro no encontrada' },
        { status: 404 }
      )
    }

    // Update the goal with new amount
    const updatedGoal = await db.savingsGoal.update({
      where: { id: goalId },
      data: {
        currentAmount: goal.currentAmount + parseFloat(amount)
      }
    })

    // Create a transaction record for this contribution
    // First, we need to get default categories and accounts
    const incomeCategory = await db.category.findFirst({
      where: {
        userId,
        type: 'income',
        name: 'Ingresos Extra'
      }
    })

    const defaultAccount = await db.account.findFirst({
      where: {
        userId,
        type: 'bank'
      }
    })

    if (incomeCategory && defaultAccount) {
      await db.transaction.create({
        data: {
          description: `Contribución a meta: ${goal.name}`,
          amount: parseFloat(amount),
          type: 'income',
          date: new Date(),
          categoryId: incomeCategory.id,
          accountId: defaultAccount.id,
          userId
        }
      })

      // Update account balance
      await db.account.update({
        where: { id: defaultAccount.id },
        data: {
          balance: defaultAccount.balance + parseFloat(amount)
        }
      })
    }

    return NextResponse.json({
      message: 'Contribución registrada exitosamente',
      goal: updatedGoal
    })

  } catch (error) {
    console.error('Error contributing to savings goal:', error)
    return NextResponse.json(
      { error: 'Error al registrar contribución' },
      { status: 500 }
    )
  }
}