import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    
    if (!userId) {
      return NextResponse.json(
        { error: 'userId es requerido' },
        { status: 400 }
      )
    }

    const categories = await db.category.findMany({
      where: {
        userId
      },
      orderBy: [
        { type: 'asc' },
        { name: 'asc' }
      ]
    })

    return NextResponse.json({
      categories
    })

  } catch (error) {
    console.error('Error fetching categories:', error)
    return NextResponse.json(
      { error: 'Error al obtener categorías' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const { name, type, icon, color, userId } = await request.json()

    if (!name || !type || !userId) {
      return NextResponse.json(
        { error: 'Nombre, tipo y userId son obligatorios' },
        { status: 400 }
      )
    }

    const category = await db.category.create({
      data: {
        name,
        type,
        icon: icon || (type === 'income' ? '💰' : '💸'),
        color: color || (type === 'income' ? '#10B981' : '#EF4444'),
        userId
      }
    })

    return NextResponse.json({
      message: 'Categoría creada exitosamente',
      category
    })

  } catch (error) {
    console.error('Error creating category:', error)
    return NextResponse.json(
      { error: 'Error al crear categoría' },
      { status: 500 }
    )
  }
}