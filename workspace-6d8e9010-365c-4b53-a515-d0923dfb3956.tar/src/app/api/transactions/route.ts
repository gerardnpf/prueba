import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    
    if (!userId) {
      return NextResponse.json(
        { error: 'userId es requerido' },
        { status: 400 }
      )
    }

    const now = new Date()
    const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1)
    const lastDayOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0)

    // Get transactions for current month
    const transactions = await db.transaction.findMany({
      where: {
        userId,
        date: {
          gte: firstDayOfMonth,
          lte: lastDayOfMonth
        }
      },
      include: {
        category: true,
        account: true
      },
      orderBy: {
        date: 'desc'
      }
    })

    // Calculate monthly stats
    const totalIncome = transactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0)

    const totalExpenses = transactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0)

    const balance = totalIncome - totalExpenses

    return NextResponse.json({
      transactions,
      monthlyStats: {
        totalIncome,
        totalExpenses,
        balance
      }
    })

  } catch (error) {
    console.error('Error fetching transactions:', error)
    return NextResponse.json(
      { error: 'Error al obtener transacciones' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const { description, amount, type, date, accountId, categoryId, userId } = await request.json()

    if (!description || !amount || !type || !date || !accountId || !categoryId || !userId) {
      return NextResponse.json(
        { error: 'Todos los campos son obligatorios' },
        { status: 400 }
      )
    }

    // Create transaction
    const transaction = await db.transaction.create({
      data: {
        description,
        amount: parseFloat(amount),
        type,
        date: new Date(date),
        accountId,
        categoryId,
        userId
      },
      include: {
        category: true,
        account: true
      }
    })

    // Update account balance
    const account = await db.account.findUnique({
      where: { id: accountId }
    })

    if (account) {
      const newBalance = type === 'income' 
        ? account.balance + amount 
        : account.balance - amount

      await db.account.update({
        where: { id: accountId },
        data: { balance: newBalance }
      })
    }

    return NextResponse.json({
      message: 'Transacción creada exitosamente',
      transaction
    })

  } catch (error) {
    console.error('Error creating transaction:', error)
    return NextResponse.json(
      { error: 'Error al crear transacción' },
      { status: 500 }
    )
  }
}