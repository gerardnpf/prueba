import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    
    if (!userId) {
      return NextResponse.json(
        { error: 'userId es requerido' },
        { status: 400 }
      )
    }

    const now = new Date()
    const currentMonth = now.getMonth() + 1
    const currentYear = now.getFullYear()

    // Get budgets for current month
    const budgets = await db.budget.findMany({
      where: {
        userId,
        month: currentMonth,
        year: currentYear
      },
      include: {
        category: true
      }
    })

    // Calculate spent amount for each budget
    const budgetsWithSpent = await Promise.all(
      budgets.map(async (budget) => {
        const firstDayOfMonth = new Date(currentYear, currentMonth - 1, 1)
        const lastDayOfMonth = new Date(currentYear, currentMonth, 0)

        const spent = await db.transaction.aggregate({
          where: {
            userId,
            categoryId: budget.categoryId,
            type: 'expense',
            date: {
              gte: firstDayOfMonth,
              lte: lastDayOfMonth
            }
          },
          _sum: {
            amount: true
          }
        })

        return {
          ...budget,
          spent: spent._sum.amount || 0
        }
      })
    )

    return NextResponse.json({
      budgets: budgetsWithSpent
    })

  } catch (error) {
    console.error('Error fetching budgets:', error)
    return NextResponse.json(
      { error: 'Error al obtener presupuestos' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const { amount, categoryId, userId, month, year } = await request.json()

    if (!amount || !categoryId || !userId) {
      return NextResponse.json(
        { error: 'Todos los campos son obligatorios' },
        { status: 400 }
      )
    }

    const now = new Date()
    const budgetMonth = month || now.getMonth() + 1
    const budgetYear = year || now.getFullYear()

    // Check if budget already exists
    const existingBudget = await db.budget.findFirst({
      where: {
        categoryId,
        month: budgetMonth,
        year: budgetYear,
        userId
      }
    })

    if (existingBudget) {
      return NextResponse.json(
        { error: 'Ya existe un presupuesto para esta categoría este mes' },
        { status: 400 }
      )
    }

    const budget = await db.budget.create({
      data: {
        amount: parseFloat(amount),
        month: budgetMonth,
        year: budgetYear,
        categoryId,
        userId
      },
      include: {
        category: true
      }
    })

    return NextResponse.json({
      message: 'Presupuesto creado exitosamente',
      budget
    })

  } catch (error) {
    console.error('Error creating budget:', error)
    return NextResponse.json(
      { error: 'Error al crear presupuesto' },
      { status: 500 }
    )
  }
}