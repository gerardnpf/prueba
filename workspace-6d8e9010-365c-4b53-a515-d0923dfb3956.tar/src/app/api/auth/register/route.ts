import { NextRequest, NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const { name, email, password } = await request.json()

    if (!name || !email || !password) {
      return NextResponse.json(
        { error: 'Todos los campos son obligatorios' },
        { status: 400 }
      )
    }

    // Check if user already exists
    const existingUser = await db.user.findUnique({
      where: { email }
    })

    if (existingUser) {
      return NextResponse.json(
        { error: 'El usuario ya existe' },
        { status: 400 }
      )
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10)

    // Create user
    const user = await db.user.create({
      data: {
        name,
        email,
        password: hashedPassword
      }
    })

    // Create default categories
    const defaultCategories = [
      // Income categories
      { name: 'Salario', type: 'income', icon: '💰', color: '#10B981' },
      { name: 'Ingresos Extra', type: 'income', icon: '💵', color: '#3B82F6' },
      { name: 'Inversiones', type: 'income', icon: '📈', color: '#8B5CF6' },
      
      // Expense categories
      { name: 'Vivienda', type: 'expense', icon: '🏠', color: '#EF4444' },
      { name: 'Comida', type: 'expense', icon: '🍔', color: '#F59E0B' },
      { name: 'Transporte', type: 'expense', icon: '🚗', color: '#3B82F6' },
      { name: 'Entretenimiento', type: 'expense', icon: '🎮', color: '#8B5CF6' },
      { name: 'Salud', type: 'expense', icon: '🏥', color: '#EC4899' },
      { name: 'Compras', type: 'expense', icon: '🛍️', color: '#14B8A6' },
      { name: 'Educación', type: 'expense', icon: '📚', color: '#F97316' },
      { name: 'Servicios', type: 'expense', icon: '💡', color: '#6366F1' },
      { name: 'Otros', type: 'expense', icon: '📌', color: '#6B7280' }
    ]

    await Promise.all(
      defaultCategories.map(category =>
        db.category.create({
          data: {
            ...category,
            userId: user.id
          }
        })
      )
    )

    // Create default accounts
    const defaultAccounts = [
      { name: 'Banco Principal', type: 'bank', balance: 0 },
      { name: 'Efectivo', type: 'cash', balance: 0 },
      { name: 'Tarjeta de Crédito', type: 'credit_card', balance: 0 }
    ]

    await Promise.all(
      defaultAccounts.map(account =>
        db.account.create({
          data: {
            ...account,
            userId: user.id
          }
        })
      )
    )

    // Return user without password
    const { password: _, ...userWithoutPassword } = user

    return NextResponse.json({
      message: 'Usuario creado exitosamente',
      user: userWithoutPassword
    })

  } catch (error) {
    console.error('Registration error:', error)
    return NextResponse.json(
      { error: 'Error al crear el usuario' },
      { status: 500 }
    )
  }
}