'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  Plus, 
  Wallet,
  CreditCard,
  DollarSign,
  Building,
  PiggyBank
} from 'lucide-react'

interface User {
  id: string
  name: string
  email: string
}

interface Account {
  id: string
  name: string
  type: string
  balance: number
}

const accountTypes = [
  { value: 'bank', label: 'Banco', icon: '🏦' },
  { value: 'cash', label: 'Efectivo', icon: '💵' },
  { value: 'credit_card', label: 'Tarjeta de Crédito', icon: '💳' },
  { value: 'savings', label: 'Ahorros', icon: '🏦' },
  { value: 'investment', label: 'Inversión', icon: '📈' },
  { value: 'other', label: 'Otro', icon: '📌' }
]

export default function AccountsPage() {
  const [user, setUser] = useState<User | null>(null)
  const [accounts, setAccounts] = useState<Account[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [newAccount, setNewAccount] = useState({
    name: '',
    type: 'bank',
    balance: '0'
  })
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem('user')
    if (!userData) {
      router.push('/login')
      return
    }

    try {
      const parsedUser = JSON.parse(userData)
      if (parsedUser && parsedUser.id) {
        setUser(parsedUser)
        fetchAccounts(parsedUser.id)
      } else {
        localStorage.removeItem('user')
        router.push('/login')
      }
    } catch (error) {
      console.error('Error parsing user data:', error)
      localStorage.removeItem('user')
      router.push('/login')
    }
  }, [router])

  const fetchAccounts = async (userId: string) => {
    try {
      const response = await fetch(`/api/accounts?userId=${userId}`)
      if (response.ok) {
        const data = await response.json()
        setAccounts(data.accounts || [])
      }
    } catch (error) {
      console.error('Error fetching accounts:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleAddAccount = async () => {
    if (!user) return

    try {
      const response = await fetch('/api/accounts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...newAccount,
          userId: user.id
        }),
      })

      if (response.ok) {
        setShowAddDialog(false)
        setNewAccount({ name: '', type: 'bank', balance: '0' })
        fetchAccounts(user.id)
      }
    } catch (error) {
      console.error('Error adding account:', error)
    }
  }

  const handleLogout = () => {
    router.push('/logout')
  }

  const getAccountIcon = (type: string) => {
    const accountType = accountTypes.find(at => at.value === type)
    return accountType?.icon || '📌'
  }

  const getAccountTypeLabel = (type: string) => {
    const accountType = accountTypes.find(at => at.value === type)
    return accountType?.label || type
  }

  const totalBalance = accounts.reduce((sum, account) => sum + account.balance, 0)

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
          <p className="mt-4 text-muted-foreground">Cargando...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return null
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold">Zen Finance</h1>
            <p className="text-muted-foreground">Gestión de Cuentas</p>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={handleLogout}>
              Cerrar Sesión
            </Button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="border-b bg-card">
        <div className="container mx-auto px-4">
          <div className="flex space-x-6">
            <Link href="/dashboard" className="py-3 px-1 border-b-2 border-transparent text-muted-foreground hover:text-foreground">
              Dashboard
            </Link>
            <Link href="/transactions" className="py-3 px-1 border-b-2 border-transparent text-muted-foreground hover:text-foreground">
              Transacciones
            </Link>
            <Link href="/accounts" className="py-3 px-1 border-b-2 border-primary text-primary font-medium">
              Cuentas
            </Link>
            <Link href="/categories" className="py-3 px-1 border-b-2 border-transparent text-muted-foreground hover:text-foreground">
              Categorías
            </Link>
            <Link href="/budgets" className="py-3 px-1 border-b-2 border-transparent text-muted-foreground hover:text-foreground">
              Presupuestos
            </Link>
            <Link href="/savings-goals" className="py-3 px-1 border-b-2 border-transparent text-muted-foreground hover:text-foreground">
              Metas de Ahorro
            </Link>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Total Balance Card */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Wallet className="h-5 w-5" />
              Balance Total
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary">
              ${totalBalance.toFixed(2)}
            </div>
            <p className="text-muted-foreground">
              Suma de todas tus cuentas
            </p>
          </CardContent>
        </Card>

        {/* Actions Bar */}
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-semibold">Tus Cuentas</h2>
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Nueva Cuenta
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Agregar Nueva Cuenta</DialogTitle>
                <DialogDescription>
                  Crea una nueva cuenta para organizar tus finanzas
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Nombre de la Cuenta</Label>
                  <Input
                    id="name"
                    value={newAccount.name}
                    onChange={(e) => setNewAccount({...newAccount, name: e.target.value})}
                    placeholder="Ej: Banco Principal"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="type">Tipo de Cuenta</Label>
                  <Select value={newAccount.type} onValueChange={(value) => setNewAccount({...newAccount, type: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {accountTypes.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.icon} {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="balance">Balance Inicial</Label>
                  <Input
                    id="balance"
                    type="number"
                    step="0.01"
                    value={newAccount.balance}
                    onChange={(e) => setNewAccount({...newAccount, balance: e.target.value})}
                    placeholder="0.00"
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowAddDialog(false)}>
                    Cancelar
                  </Button>
                  <Button onClick={handleAddAccount}>
                    Crear Cuenta
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Accounts Grid */}
        {accounts.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <Wallet className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No hay cuentas registradas</h3>
              <p className="text-muted-foreground mb-4">
                Crea tu primera cuenta para empezar a organizar tus finanzas
              </p>
              <Button onClick={() => setShowAddDialog(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Crear Primera Cuenta
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {accounts.map((account) => (
              <Card key={account.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="text-2xl">{getAccountIcon(account.type)}</div>
                      <div>
                        <CardTitle className="text-lg">{account.name}</CardTitle>
                        <CardDescription>{getAccountTypeLabel(account.type)}</CardDescription>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm text-muted-foreground">Balance Actual</p>
                      <p className={`text-2xl font-bold ${
                        account.balance >= 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        ${account.balance.toFixed(2)}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" className="flex-1">
                        <DollarSign className="h-4 w-4 mr-1" />
                        Ingresar
                      </Button>
                      <Button variant="outline" size="sm" className="flex-1">
                        <CreditCard className="h-4 w-4 mr-1" />
                        Retirar
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}